# @harrishill/board-sdk

Build web games for **Board**, the tabletop gaming platform with physical piece tracking.

The Board Web SDK is a thin TypeScript wrapper over the JavaScript bridges injected into the Board WebView by the host OS. It exposes APIs for touch and piece input, multiplayer sessions, save games, player profiles, and the system pause menu.

> **Alpha.** APIs may change before 1.0. Reach out to the Board team if you hit rough edges.

## Install

### From a tarball

```bash
npm install ./harrishill-board-sdk-0.1.0.tgz
```

### From GitHub (once you have access)

```bash
npm install github:Harris-Hill/board-web-sdk
```

## Quickstart

```ts
import { Board, BoardContactType } from "@harrishill/board-sdk";

if (Board.isOnDevice) {
  // 1. Subscribe to touch and piece input (~60fps)
  Board.input.subscribe((contacts) => {
    for (const c of contacts) {
      if (c.type === BoardContactType.Glyph) {
        console.log(`Piece ${c.glyphId} at (${c.x}, ${c.y}) rotation ${c.orientation}°`);
      }
    }
  });

  // 2. Read session players
  const players = Board.session.getPlayers();
  console.log(`${players.length} players in session`);

  // 3. Configure the system pause menu
  Board.pause.setContext({
    gameName: "My Game",
    offerSaveOption: true,
  });
}
```

## API overview

| Namespace | Purpose |
|---|---|
| `Board.input` | Touch and piece (Glyph) contacts, delivered at sensor frame rate. |
| `Board.session` | Multiplayer session: players, guest add/remove, profile switcher. |
| `Board.save` | Save-game create/load/update/delete, cover images, storage limits. |
| `Board.pause` | System pause menu: custom buttons, audio track sliders, result polling. |
| `Board.avatar` | Load player avatar images as data URIs. |
| `Board.isOnDevice` | `true` when running inside a Board WebView. Always check first. |
| `Board.sdkVersion` | SDK semver string. |
| `Board.bridgeVersion` | Host OS bridge API version, for feature gating across OS releases. |

## Running outside a Board device

In a normal browser (local dev, CI), `Board.isOnDevice` is `false` and any API call will throw. Gate your Board code behind `isOnDevice` so the same bundle can run both on a Board and in a regular browser for preview or testing.

## Forward/backward compatibility

The SDK ships inside your game. The bridge ships inside the Board OS. They update independently, so three scenarios must all work:

| Scenario | Behavior |
|---|---|
| Old SDK + New OS | Existing games continue to work. |
| New SDK + Old OS | New methods degrade gracefully or throw a clear error. Use `Board.bridgeVersion` to feature-gate. |
| New SDK + New OS | Full feature set. |

```ts
if ((Board.bridgeVersion ?? 0) >= 2) {
  // call a V2-only API safely
}
```

## Requirements

- Node 18+ for the build toolchain
- Any modern ESM-compatible bundler (Vite, webpack 5, esbuild, rollup, Parcel)
- A Board device, or the SDK's browser preview harness, for runtime

## Documentation

- Full developer docs: https://docs.dev.board.fun/
- Developer portal: https://dev.board.fun/
- Contact: hello@board.fun

## License

See [LICENSE](./LICENSE). Full license terms are published at https://docs.dev.board.fun/more/license.
